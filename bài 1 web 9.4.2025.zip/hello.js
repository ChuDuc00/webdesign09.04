document.write("Hello world<br>");  // Viết ra màn hình
alert("Hello world");               // Thông báo alert
